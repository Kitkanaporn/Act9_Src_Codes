/** @type {import("../models/itemModel").Item[]} */
export const items = [];
