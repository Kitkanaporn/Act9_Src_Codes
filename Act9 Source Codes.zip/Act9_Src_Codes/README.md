# Activity 9 Backend

This repository contains source code for backend (as well as frontend) for activity 8 in the class "Computer Engineering Essentials".
As this activity focuses on how backend works, the backend stores data in memory, instead of in database.

To download the source code, you can clone with git or download as a zip file (click a green button "< > Code" on the top right of this readme and select Download Zip).
Unzip the file and then move to your remote server using VScode.
